﻿// Import MMMReader SDK
using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Application start");
        //Init reader

        InitialiseReader();

        Console.WriteLine("Press any key to exit.");
        Console.ReadKey(); // Keep the console window open until a key is pressed


    }


    //DataCallBack function 
    static void DataCallBack(MMM.Readers.FullPage.DataType aDataType, object aData)
    {
        Console.WriteLine("test3");
        switch (aDataType)
        {
            case MMM.Readers.FullPage.DataType.CD_CODELINE:
                Console.WriteLine("test1");
                break;

            case MMM.Readers.FullPage.DataType.CD_CODELINE_DATA:
                Console.WriteLine("test2");
                break;
            case MMM.Readers.FullPage.DataType.CD_IMAGEIR:
                //Console.WriteLine(MMM.Readers.FullPage.DataType.CD_IMAGEIR);
                Console.WriteLine("test4");
                break;
            case MMM.Readers.FullPage.DataType.CD_IMAGEUV:
                Console.WriteLine(MMM.Readers.FullPage.DataType.CD_IMAGEUV);
                break;
            case MMM.Readers.FullPage.DataType.CD_IMAGEVIS:
                Console.WriteLine(MMM.Readers.FullPage.DataType.CD_IMAGEVIS);
                break;
        }

    }
    //eventDelegate call back function to handle events from reader
    static void EventCallBack(MMM.Readers.FullPage.EventCode aEventType)
    {
        /* Console.WriteLine($"Event: {aEventType}");
         Console.WriteLine($"State: {MMM.Readers.FullPage.Reader.GetState()}");
         switch (aEventType)
         {
             //handle SETTING_INITIALISE EVENT
             case MMM.Readers.FullPage.EventCode.SETTINGS_INITIALISED:
                 {
                     MMM.Readers.FullPage.ReaderSettings settings;
                     MMM.Readers.ErrorCode errorCode = MMM.Readers.FullPage.Reader.GetSettings(
                                 out settings
                             );
                     if (errorCode == MMM.Readers.ErrorCode.NO_ERROR_OCCURRED)
                     {
                         settings.puDataToSend.send |=
                                    MMM.Readers.FullPage.DataSendSet.Flags.DOCMARKERS;
                         settings.puDataToSend.special |=
                             MMM.Readers.FullPage.DataSendSet.Flags.VISIBLEIMAGE |
                             MMM.Readers.FullPage.DataSendSet.Flags.IRIMAGE | MMM.Readers.FullPage.DataSendSet.Flags.UVIMAGE;
                         MMM.Readers.FullPage.Reader.UpdateSettings(settings);
                     }

                     break;
                 }
             case MMM.Readers.FullPage.EventCode.PLUGINS_INITIALISED:
                 {
                     int lIndex = 0;
                     string lPluginName = "";

                     while (
                         MMM.Readers.FullPage.Reader.GetPluginName(
                             ref lPluginName,
                             lIndex
                         ) == MMM.Readers.ErrorCode.NO_ERROR_OCCURRED &&
                         lPluginName.Length > 0
                     )
                     {
                         Console.WriteLine("Plugin Found: " + lPluginName);
                         ++lIndex;
                     }
                     break;
                 }

         }

 */
        try
        {
            Console.WriteLine($"Event: {aEventType}");
            Console.WriteLine($"State: {MMM.Readers.FullPage.Reader.GetState()}");

            switch (aEventType)
            {
                case MMM.Readers.FullPage.EventCode.SETTINGS_INITIALISED:
                    {
                        // You may wish to change the settings immediately after they have 
                        // been loaded - for example, to turn off options that you do not 
                        // want.
                        MMM.Readers.FullPage.ReaderSettings settings;
                        MMM.Readers.ErrorCode errorCode = MMM.Readers.FullPage.Reader.GetSettings(
                            out settings
                        );
                        Console.WriteLine(errorCode);
                        if (errorCode == MMM.Readers.ErrorCode.NO_ERROR_OCCURRED)
                        {
                            /*if (settings.puCameraSettings.puSplitImage == false)
                                this.tabControl.Controls.Remove(this.ImagesRearTab);*/ //UI

                            settings.puDataToSend.send |=
                                 MMM.Readers.FullPage.DataSendSet.Flags.DOCMARKERS;
                            settings.puDataToSend.special |=
                                MMM.Readers.FullPage.DataSendSet.Flags.VISIBLEIMAGE |
                                MMM.Readers.FullPage.DataSendSet.Flags.IRIMAGE;

                            settings.puDataToSend.special &= ~MMM.Readers.FullPage.DataSendSet.Flags.UVIMAGE;

                            MMM.Readers.FullPage.Reader.UpdateSettings(settings);
                            //string lPath = ".\\settings_data.txt";
                            //MMM.Readers.FullPage.Reader.WriteTextfileSettings(settings, ref lPath);
                            MMM.Readers.FullPage.Reader.EnableLogging(
                                true,
                                5,
                                (int)settings.puLoggingSettings.logMask,
                                "C:/Software Projects/Thales Scanner/Logs/licenseScanner.Net.log"
                            );
                        }
                        else
                        {
                            Console.WriteLine(
                                "GetSettings failure, check for Settings " +
                                "structure mis-match. Error: " +
                                errorCode.ToString(),
                                "Error"
                            );
                        }
                        break;
                    }
                case MMM.Readers.FullPage.EventCode.DOC_ON_WINDOW:
                    {
                        // If using a CR5400, you can control insertion of the document by setting the initial reader 
                        // state to READER_DISABLED, which will leave the card in the up position in the reader.
                        // When you receive DOC_ON_WINDOW here, you can insert the document and enable the
                        // reader to process the document.  Then, on END_OF_DOCUMENT_DATA, set the reader state back to READER_DISABLED.
                        //if (MMM.Readers.FullPage.Reader.GetState() == MMM.Readers.FullPage.ReaderState.READER_DISABLED)
                        //{
                        //    MMM.Readers.FullPage.Reader.InsertDocument();
                        //    MMM.Readers.FullPage.Reader.SetState(MMM.Readers.FullPage.ReaderState.READER_ENABLED, false);
                        //}
                        prDocStartTime = DateTime.UtcNow;
                        //Clear();
                        break;
                    }
                case MMM.Readers.FullPage.EventCode.PLUGINS_INITIALISED:
                    {
                        int lIndex = 0;
                        string lPluginName = "";

                        while (
                            MMM.Readers.FullPage.Reader.GetPluginName(
                                ref lPluginName,
                                lIndex
                            ) == MMM.Readers.ErrorCode.NO_ERROR_OCCURRED &&
                            lPluginName.Length > 0
                        )
                        {

                            Console.WriteLine($"Time: {System.DateTime.UtcNow.ToLongTimeString()}");
                            Console.WriteLine($"Plugin found: {lPluginName}");


                            //							//Example of how to enable a plugin
                            //							MMM.Readers.FullPage.Reader.EnablePlugin(
                            //								lPluginName,
                            //								true
                            //							);
                            lIndex++;
                        }

                        // The folloiwng code shows how to enable Hardware AutoCapture on the AT10K 550.
                        // This requires setting detection to ActiveReader mode (on reader firmware) and
                        // enabling AutoCapture.  This should result in faster image capture time for improved
                        // document reading times and better images for decoding barcodes on paper/phones.
                        //MMM.Readers.ErrorCode result = MMM.Readers.ErrorCode.NO_ERROR_OCCURRED;
                        //MMM.Readers.FullPage.HardwareConfig hardwareConfig = MMM.Readers.Modules.Reader.GetHardwareConfig(false);

                        //var firmwareVersion = new string(hardwareConfig.puLCBPartNum);
                        //if (!string.IsNullOrEmpty(firmwareVersion) && firmwareVersion.StartsWith("FW00286")) // AT10K 550 DPI
                        //{
                        //    MMM.Readers.FullPage.ReaderSettings settings;
                        //    result = MMM.Readers.FullPage.Reader.GetSettings(
                        //        out settings
                        //    );
                        //    if (result == MMM.Readers.ErrorCode.NO_ERROR_OCCURRED)
                        //    {
                        //        settings.puCameraSettings.flap = 0x20;
                        //        settings.puDocDetectSettings.useHardwareAutoCapture = 1;

                        //        result = MMM.Readers.FullPage.Reader.UpdateSettings(settings);
                        //    }

                        //}

                        break;
                    }
                case MMM.Readers.FullPage.EventCode.END_OF_DOCUMENT_DATA:
                    {
                        TimeSpan duration = DateTime.UtcNow - prDocStartTime;
                        float docTime = duration.Ticks / TimeSpan.TicksPerSecond;
                        Console.WriteLine("Time: " + docTime.ToString() + "s");


                        //if (MMM.Readers.FullPage.Reader.GetState() != MMM.Readers.FullPage.ReaderState.READER_DISABLED)
                        //{
                        //    MMM.Readers.FullPage.Reader.SetState(MMM.Readers.FullPage.ReaderState.READER_DISABLED, false);
                        //}
                        break;
                    }
            }

            //UpdateState(MMM.Readers.FullPage.Reader.GetState()); UI Element
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
        }
    }

    //certificate delegate to attach to initilisation function
    static bool CertificateCallback(byte[] aCertIdentifier, MMM.Readers.Modules.RF.CertType aCertType, out byte[] aCertBuffer)
    {
        Console.WriteLine("Certificate Called.");

        // Initialize aCertBuffer
        aCertBuffer = new byte[256];  // Assuming 256 as an example size; adjust as necessary.

        // You should add logic to determine the return value based on your application's needs.
        // Return true if the operation is successful, or false otherwise.
        return true;
    }

    //warning callbac
    static void WarningCallBack(MMM.Readers.WarningCode aWarningCode, string aWarningMessage)
    {
        Console.WriteLine($"Error Code: {aWarningCode}, Message: {aWarningMessage}");
    }
    static void ErrorCallback(MMM.Readers.ErrorCode aErrorCode, string aErrorMessage)
    {
        Console.WriteLine($"Error Code: {aErrorCode}, Message: {aErrorMessage}");
    }
    //initialise the reader 

    static void InitialiseReader()
    {

        try
        {
            //initialise reader
            MMM.Readers.ErrorCode lResult = MMM.Readers.FullPage.Reader.Initialise(
                new MMM.Readers.FullPage.DataDelegate(DataCallBack),
                new MMM.Readers.FullPage.EventDelegate(EventCallBack),
                new MMM.Readers.ErrorDelegate(ErrorCallback),
                new MMM.Readers.FullPage.CertificateDelegate(CertificateCallback),
                true,
                false
            );
            MMM.Readers.FullPage.Reader.SetWarningCallback(new MMM.Readers.WarningDelegate(WarningCallBack));
        }
        catch (System.Exception ex)
        {
            //log error
            Console.WriteLine(ex);

        }


    }
    protected static DateTime prDocStartTime = DateTime.UtcNow;


}
